# ===========================================================
# Healthcare NER Model pipeline - pre-trained MLM models search step (Step 1)
#
# Search for candidate MLM models from Hugging Face Hub
#
# dependencies:
#    mlpipeline_data_helpers.py - helper functions to transfer data between steps
#
# Environment variables required:
#     DATA_LOCATION - Object storage bucket to use for temporary data transfer between steps
# 
# ============================================================

import ads 
print("ADS version (requires version 2.6.1 or above): ", ads.__version__)


# --------------------------------
# Search Models from HF Hub
# --------------------------------


from huggingface_hub import list_models

# Fetch the list of models with the specified criteria
models = list_models(
    language ="fr", task="fill-mask", library = "pytorch", cardData = True
)


# List of tags to filter by
filter_tags = ["healthcare", "medical",  "clinical", "biomedical", "biology", "life science"]

# Print the model IDs and some basic information
included_models = []
for model in models:
    if  len(model.card_data.language) == 1 and \
        model.card_data.library_name == 'transformers' and \
        any(tag in model.tags for tag in filter_tags):

      included_models.append(model.modelId)


# --------------------------------
# Check the Models Configuration
# --------------------------------

from transformers import AutoConfig

# List of models to check
model_ids = included_models
# Initialize an empty dictionary to store model ID and their details
models_with_right_config = []

# Function to fetch the number of layers and attention heads
def get_model_details(model_id):
    try:
        # Load the model configuration
        config = AutoConfig.from_pretrained(model_id, trust_remote_code=False)

        # Get the number of layers and attention heads
        num_layers = config.num_hidden_layers
        num_heads = config.num_attention_heads

        return num_layers, num_heads
    except Exception as e:
        return f"Error retrieving config for {model_id}: {e}", None

# Iterate through the models and populate the dictionary with their details
for model_id in model_ids:
    details = get_model_details(model_id)
    if details[0] == 12 and details[1] == 12:
      models_with_right_config.append(model_id)


# --------------------------------
# Retrieve  Mask Tokens
# --------------------------------


from transformers import AutoTokenizer

# Initialize an empty dictionary to store model ID and mask token
models_with_mask_tokens = {}

# Function to fetch the mask token using the tokenizer
def get_mask_token_via_tokenizer(model_id):
    try:
        # Load the tokenizer
        tokenizer = AutoTokenizer.from_pretrained(model_id)

        # Get the mask token
        return tokenizer.mask_token
    except Exception as e:
        return f"Error retrieving tokenizer for {model_id}: {e}"

# Iterate through the models and populate the dictionary with mask tokens
for model_id in models_with_right_config:
    mask_token = get_mask_token_via_tokenizer(model_id)
    if mask_token in ["[MASK]", "<mask>"]:
        models_with_mask_tokens[model_id] = mask_token

# Print the constructed dictionary
print("models_with_mask_tokens:")
print(models_with_mask_tokens)


# --------------------------------
# Pass the top-5 MLM models to the next pipline step
# --------------------------------

# import the helper functions
from mlpipeline_data_helpers import MLPipelineDataHelper
    
import json

# Convert the list of dictionaries to a JSON string
models_with_mask_tokens_json = json.dumps(models_with_mask_tokens)

# Print the JSON string
print("\nFound models with mask tokens:")
print(models_with_mask_tokens)


# pass a simple value to the next step
MLPipelineDataHelper.set_pipeline_param('FOUND_MLM_MODELS', models_with_mask_tokens_json)
