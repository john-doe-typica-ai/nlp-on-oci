# ===========================================================
# Healthcare NER Model pipeline - pre-trained MLM models ranking step (Step 2)
#
# Evaluate and Rank the candidate MLM models found in the previous pipeline step
#
# dependencies:
#    mlpipeline_data_helpers.py - helper functions to transfer data between steps
#
# Environment variables required:
#     DATA_LOCATION - Object storage bucket to use for temporary data transfer between steps
# 
# ============================================================

import ads 
print("ADS version (requires version 2.6.1 or above): ", ads.__version__)


# --------------------------------
# Retreive the list of found MLM models from previous pipeline step
# --------------------------------


# import the helper functions
from mlpipeline_data_helpers import MLPipelineDataHelper
    
import json


found_mlm_models_str = MLPipelineDataHelper.get_pipeline_param('FOUND_MLM_MODELS')

print(found_mlm_models_str)

found_mlm_models_json_obj = json.loads(found_mlm_models_str)


# --------------------------------
# Evaluate and Rank the found Models Based on Entity Prediction
# --------------------------------


from transformers import pipeline


# Define the generic expected entities with their weights
generic_expected_entities = [
    {'médicaments': 0.3},
    {'traitements': 0.3},
    {'soins': 0.3},
    {'remèdes': 0.3},
    {'conseils': 0.1},
    {'indications': 0.1},
    {'instructions': 0.05},
    {'interventions': 0.05},
    {'compléments': 0.05}
]


# Define the examples and their specific expected entities
examples = [
    {
        "text": "Le medecin donne des {} en cas d'infections des voies respiratoires.",
        "expected_entities": [{'antibiotiques': 1}]
    },
    {
        "text": "Le médecin recommande des {} pour réduire l'inflammation dans les poumons.",
        "expected_entities": [{'corticoïdes': 1}, {'anti-inflammatoires': 0.9}]
    },
    {
        "text": "Pour soulager les symptômes d'allergie, le médecin prescrit des {}.",
        "expected_entities": [{'antihistaminiques': 1}]
    },
    {
        "text": "Pour gérer le diabète, le médecin prescrit une {}.",
        "expected_entities": [{'insulinothérapie': 1}]
    },
    {
        "text": "Après une blessure musculaire, le patient doit suivre une {}.",
        "expected_entities": [{'physiothérapie': 1}, {'rééducation': 0.8}]
    },
    {
        "text": "En cas d'infection bactérienne, le médecin recommande une {}.",
        "expected_entities": [{'antibiothérapie': 1}]
    }
]

models = found_mlm_models_json_obj

# Initialize a dictionary to store the cumulative scores for each model
model_scores = {model_name: 0 for model_name in models}

# Iterate over each model
for model_name, mask_token in models.items():
    print(f"Testing {model_name} ...")
    try:
      # Load the fill-mask pipeline for the current model
      fill_mask = pipeline("fill-mask", model=model_name, tokenizer=model_name, trust_remote_code=False)

      # Iterate over each example
      for example in examples:
          # Prepare the example sentence with the correct mask token
          masked_example = example["text"].format(mask_token)
          specific_expected_entities = example["expected_entities"]

          # Combine generic and specific entities, giving priority to specific ones
          combined_expected_entities = {**{k: v for d in generic_expected_entities for k, v in d.items()}, **{k: v for d in specific_expected_entities for k, v in d.items()}}
          # Get predictions
          results = fill_mask(masked_example)

          # Extract the top predicted tokens
          predicted_tokens = [result['token_str'] for result in results]

          # Calculate a score based on matching expected entities
          score = 0
          for entity, weight in combined_expected_entities.items():
              if entity in predicted_tokens:
                  score += weight

          # Add the score to the cumulative score for the model
          model_scores[model_name] += score

    except:
      print(f"Error in {model_name}")


# --------------------------------
# Pass the top-5 MLM models to the next pipline step
# --------------------------------


import json

# Rank models based on their cumulative scores
ranked_models = sorted(model_scores.items(), key=lambda item: item[1], reverse=True)

# Print the final ranking
top5_mlm_models = []
print("\nModel Ranking based on Weighted Entity Match Scores (top-5): ")
for rank, (model_name, score) in enumerate(ranked_models, 1):
    #print only the top-5 models
    if rank <= 5:
        model_dict = {"rank": rank, "model_name": model_name, "score": score}
        top5_mlm_models.append(model_dict)
        print(f"{rank}. {model_name}: Cumulative Score = {score}")


# Convert the list of dictionaries to a JSON string
top5_mlm_models_json_str = json.dumps(top5_mlm_models)

# Print the JSON string
print("\nTop 5 MLM Models as JSON string:")
print(top5_mlm_models_json_str)


# pass a simple value to the next step
MLPipelineDataHelper.set_pipeline_param('TOP5_MLM_MODELS', top5_mlm_models_json_str)

